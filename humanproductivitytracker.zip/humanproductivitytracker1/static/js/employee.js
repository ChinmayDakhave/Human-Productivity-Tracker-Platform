// Employee Dashboard Logic
// Chart.js is loaded via CDN in HTML

const API_BASE = window.location.origin
let currentUser = null
let sessionActive = false
let weeklyTrendChart = null
let appUsageChart = null

// Initialization
document.addEventListener("DOMContentLoaded", async () => {
  // Check authentication
  currentUser = JSON.parse(localStorage.getItem("user"))
  if (!currentUser || currentUser.role === "ADMIN") {
    window.location.href = "/index.html"
    return
  }

  // Update UI with user info
  updateUserInfo()

  // Set current date
  document.getElementById("currentDate").textContent = new Date().toLocaleDateString("en-US", {
    weekday: "long",
    year: "numeric",
    month: "long",
    day: "numeric",
  })

  // Initialize navigation
  initNavigation()

  // Initialize form handlers
  initForms()

  // Load dashboard data
  await loadDashboardData()

  // Initialize charts
  initCharts()
})

// User Info
function updateUserInfo() {
  document.getElementById("userAvatar").textContent = currentUser.avatar
  document.getElementById("userName").textContent = currentUser.name
  document.getElementById("userTeam").textContent = currentUser.team + " Team"
}

// Navigation
function initNavigation() {
  const navItems = document.querySelectorAll(".nav-item[data-section]")
  navItems.forEach((item) => {
    item.addEventListener("click", (e) => {
      e.preventDefault()
      const section = item.dataset.section
      switchSection(section)
    })
  })
}

function switchSection(sectionId) {
  // Update nav items
  document.querySelectorAll(".nav-item").forEach((item) => {
    item.classList.remove("active")
    if (item.dataset.section === sectionId) {
      item.classList.add("active")
    }
  })

  // Update sections
  document.querySelectorAll(".section").forEach((section) => {
    section.classList.remove("active")
  })
  document.getElementById(sectionId + "-section").classList.add("active")

  // Update page title
  const titles = {
    overview: "Dashboard Overview",
    "log-activity": "Log Work Activity",
    history: "Activity History",
    insights: "Personal Insights",
  }
  document.getElementById("pageTitle").textContent = titles[sectionId] || "Dashboard"

  // Load section-specific data
  if (sectionId === "history") {
    loadHistory()
  } else if (sectionId === "insights") {
    loadInsights()
  }
}

// Session Management
async function toggleSession() {
  const btn = document.getElementById("sessionBtn")
  const status = document.getElementById("sessionStatus")

  if (!sessionActive) {
    // Start session
    try {
      await fetch(`${API_BASE}/api/sessions/start`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ user_id: currentUser.user_id }),
      })

      sessionActive = true
      btn.textContent = "End Session"
      btn.classList.remove("btn-primary")
      btn.classList.add("btn-danger")
      status.innerHTML = '<span class="status-dot active"></span><span>Session Active</span>'
    } catch (error) {
      console.error("Error starting session:", error)
    }
  } else {
    // End session
    try {
      await fetch(`${API_BASE}/api/sessions/end`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ user_id: currentUser.user_id }),
      })

      sessionActive = false
      btn.textContent = "Start Session"
      btn.classList.remove("btn-danger")
      btn.classList.add("btn-primary")
      status.innerHTML = '<span class="status-dot inactive"></span><span>Session Inactive</span>'

      // Reload dashboard data
      await loadDashboardData()
    } catch (error) {
      console.error("Error ending session:", error)
    }
  }
}

// Dashboard Data Loading
async function loadDashboardData() {
  try {
    // Fetch productivity metrics
    const metricsRes = await fetch(`${API_BASE}/api/productivity?user_id=${currentUser.user_id}`)
    const metrics = await metricsRes.json()

    // Fetch today's logs
    const logsRes = await fetch(`${API_BASE}/api/today-logs/${currentUser.user_id}`)
    const todayLogs = await logsRes.json()

    // Fetch work sessions
    const sessionsRes = await fetch(`${API_BASE}/api/sessions?user_id=${currentUser.user_id}`)
    const sessions = await sessionsRes.json()

    // Update stats
    updateStats(metrics, todayLogs, sessions)

    // Update today's logs table
    updateTodayLogsTable(todayLogs)

    // Update recent entries
    updateRecentEntries(todayLogs)
  } catch (error) {
    console.error("Error loading dashboard data:", error)
  }
}

function updateStats(metrics, todayLogs, sessions) {
  // Today's hours
  const today = new Date().toISOString().split("T")[0]
  const todaySession = sessions.find((s) => s.date === today)
  if (todaySession && todaySession.total_minutes > 0) {
    const hours = Math.floor(todaySession.total_minutes / 60)
    const mins = todaySession.total_minutes % 60
    document.getElementById("todayHours").textContent = `${hours}h ${mins}m`
  }

  // Productivity score (average of last 7 days)
  const recentMetrics = metrics.slice(0, 7)
  if (recentMetrics.length > 0) {
    const avgScore = Math.round(recentMetrics.reduce((sum, m) => sum + m.productivity_score, 0) / recentMetrics.length)
    document.getElementById("productivityScore").textContent = avgScore + "%"
  }

  // Tasks logged today
  document.getElementById("tasksLogged").textContent = todayLogs.length

  // Burnout risk
  const latestMetric = metrics.find((m) => m.date === today) || metrics[0]
  if (latestMetric) {
    const burnoutEl = document.getElementById("burnoutRisk")
    burnoutEl.textContent = latestMetric.burnout_risk
    burnoutEl.className = "stat-value"
    if (latestMetric.burnout_risk === "HIGH") {
      burnoutEl.style.color = "var(--danger)"
    } else if (latestMetric.burnout_risk === "MEDIUM") {
      burnoutEl.style.color = "var(--warning)"
    } else {
      burnoutEl.style.color = "var(--success)"
    }
  }
}

function updateTodayLogsTable(logs) {
  const tbody = document.getElementById("todayLogsTable")

  if (logs.length === 0) {
    tbody.innerHTML = '<tr><td colspan="5" class="text-center text-muted">No activities logged today</td></tr>'
    return
  }

  tbody.innerHTML = logs
    .slice(0, 5)
    .map(
      (log) => `
        <tr>
            <td>
                <div class="flex items-center gap-2">
                    <span class="category-dot ${log.app_category}"></span>
                    ${log.application}
                </div>
            </td>
            <td>${log.start_time} - ${log.end_time}</td>
            <td>${log.duration} mins</td>
            <td>${log.task_category}</td>
            <td><span class="badge badge-${log.app_category === "productive" ? "success" : log.app_category === "neutral" ? "warning" : "danger"}">${log.app_category}</span></td>
        </tr>
    `,
    )
    .join("")
}

function updateRecentEntries(logs) {
  const container = document.getElementById("recentEntries")

  if (logs.length === 0) {
    container.innerHTML = `
            <div class="empty-state">
                <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
                    <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
                    <polyline points="14 2 14 8 20 8"/>
                    <line x1="12" y1="18" x2="12" y2="12"/>
                    <line x1="9" y1="15" x2="15" y2="15"/>
                </svg>
                <p>No entries logged yet today</p>
            </div>
        `
    return
  }

  container.innerHTML = logs
    .map(
      (log) => `
        <div class="activity-entry ${log.app_category}">
            <div class="app-icon">${log.application.substring(0, 2).toUpperCase()}</div>
            <div class="activity-details">
                <div class="app-name">${log.application}</div>
                <div class="task-desc">${log.task_description || log.task_category}</div>
            </div>
            <div class="activity-meta">
                <div class="time-range">${log.start_time} - ${log.end_time}</div>
                <div class="duration">${log.duration} minutes</div>
            </div>
        </div>
    `,
    )
    .join("")
}

// Charts
async function initCharts() {
  try {
    const trendsRes = await fetch(`${API_BASE}/api/analytics/trends?user_id=${currentUser.user_id}&days=7`)
    const trends = await trendsRes.json()

    const logsRes = await fetch(`${API_BASE}/api/app-usage?user_id=${currentUser.user_id}`)
    const logs = await logsRes.json()

    // Weekly trend chart
    const trendCtx = document.getElementById("weeklyTrendChart").getContext("2d")
    weeklyTrendChart = new window.Chart(trendCtx, {
      type: "line",
      data: {
        labels: trends.map((t) => t.day),
        datasets: [
          {
            label: "Productivity Score",
            data: trends.map((t) => t.productivity_score),
            borderColor: "#2563eb",
            backgroundColor: "rgba(37, 99, 235, 0.1)",
            fill: true,
            tension: 0.4,
          },
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { display: false },
        },
        scales: {
          y: {
            beginAtZero: true,
            max: 100,
            grid: { color: "rgba(0, 0, 0, 0.05)" },
          },
          x: {
            grid: { display: false },
          },
        },
      },
    })

    // App usage pie chart
    const recentLogs = logs.slice(0, 100)
    const productive = recentLogs.filter((l) => l.app_category === "productive").length
    const neutral = recentLogs.filter((l) => l.app_category === "neutral").length
    const unproductive = recentLogs.filter((l) => l.app_category === "unproductive").length

    const usageCtx = document.getElementById("appUsageChart").getContext("2d")
    appUsageChart = new window.Chart(usageCtx, {
      type: "doughnut",
      data: {
        labels: ["Productive", "Neutral", "Unproductive"],
        datasets: [
          {
            data: [productive, neutral, unproductive],
            backgroundColor: ["#10b981", "#f59e0b", "#ef4444"],
            borderWidth: 0,
          },
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            position: "bottom",
          },
        },
      },
    })
  } catch (error) {
    console.error("Error initializing charts:", error)
  }
}

// Forms
function initForms() {
  const activityForm = document.getElementById("activityForm")
  const startTime = document.getElementById("startTime")
  const endTime = document.getElementById("endTime")
  const duration = document.getElementById("duration")

  // Auto-calculate duration
  const calculateDuration = () => {
    if (startTime.value && endTime.value) {
      const start = new Date(`2000-01-01 ${startTime.value}`)
      const end = new Date(`2000-01-01 ${endTime.value}`)
      const diff = (end - start) / 1000 / 60
      duration.value = diff > 0 ? Math.round(diff) : 0
    }
  }

  startTime.addEventListener("change", calculateDuration)
  endTime.addEventListener("change", calculateDuration)

  // Form submission
  activityForm.addEventListener("submit", async (e) => {
    e.preventDefault()

    const formData = {
      user_id: currentUser.user_id,
      application: document.getElementById("application").value,
      task_category: document.getElementById("taskCategory").value,
      start_time: startTime.value,
      end_time: endTime.value,
      duration: Number.parseInt(duration.value) || 0,
      task_description: document.getElementById("taskDescription").value,
    }

    try {
      const res = await fetch(`${API_BASE}/api/app-usage`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      })

      if (res.ok) {
        resetForm()
        await loadDashboardData()
        alert("Activity logged successfully!")
      }
    } catch (error) {
      console.error("Error logging activity:", error)
      alert("Error logging activity. Please try again.")
    }
  })
}

function resetForm() {
  document.getElementById("activityForm").reset()
  document.getElementById("duration").value = ""
}

// History
async function loadHistory() {
  const days = Number.parseInt(document.getElementById("historyFilter").value) || 7
  const tbody = document.getElementById("historyTable")

  try {
    const [metricsRes, sessionsRes] = await Promise.all([
      fetch(`${API_BASE}/api/productivity?user_id=${currentUser.user_id}`),
      fetch(`${API_BASE}/api/sessions?user_id=${currentUser.user_id}`),
    ])

    const metrics = await metricsRes.json()
    const sessions = await sessionsRes.json()

    // Combine data by date
    const historyData = []
    for (let i = 0; i < days; i++) {
      const date = new Date()
      date.setDate(date.getDate() - i)
      const dateStr = date.toISOString().split("T")[0]

      const session = sessions.find((s) => s.date === dateStr)
      const metric = metrics.find((m) => m.date === dateStr)

      if (session || metric) {
        historyData.push({
          date: dateStr,
          login: session?.login_time || "--",
          logout: session?.logout_time || "--",
          totalMins: session?.total_minutes || 0,
          score: metric?.productivity_score || 0,
          burnout: metric?.burnout_risk || "N/A",
        })
      }
    }

    if (historyData.length === 0) {
      tbody.innerHTML = '<tr><td colspan="6" class="text-center text-muted">No history data available</td></tr>'
      return
    }

    tbody.innerHTML = historyData
      .map((row) => {
        const hours = Math.floor(row.totalMins / 60)
        const mins = row.totalMins % 60
        return `
            <tr>
                <td>${new Date(row.date).toLocaleDateString("en-US", { weekday: "short", month: "short", day: "numeric" })}</td>
                <td>${row.login}</td>
                <td>${row.logout}</td>
                <td>${hours}h ${mins}m</td>
                <td>
                    <div class="flex items-center gap-2">
                        <div class="progress-bar" style="width: 60px;">
                            <div class="progress-fill ${row.score >= 70 ? "green" : row.score >= 50 ? "yellow" : "red"}" style="width: ${row.score}%"></div>
                        </div>
                        <span>${row.score}%</span>
                    </div>
                </td>
                <td><span class="badge badge-${row.burnout === "HIGH" ? "danger" : row.burnout === "MEDIUM" ? "warning" : "success"}">${row.burnout}</span></td>
            </tr>
        `
      })
      .join("")
  } catch (error) {
    console.error("Error loading history:", error)
    tbody.innerHTML = '<tr><td colspan="6" class="text-center text-muted">Error loading history</td></tr>'
  }
}

function filterHistory() {
  loadHistory()
}

// Insights
async function loadInsights() {
  try {
    const [metricsRes, logsRes, empRes] = await Promise.all([
      fetch(`${API_BASE}/api/productivity?user_id=${currentUser.user_id}`),
      fetch(`${API_BASE}/api/app-usage?user_id=${currentUser.user_id}`),
      fetch(`${API_BASE}/api/employees/${currentUser.user_id}`),
    ])

    const metrics = await metricsRes.json()
    const logs = await logsRes.json()
    const employee = await empRes.json()

    // Calculate streak
    let streak = 0
    for (const metric of metrics) {
      if (metric.productivity_score >= 70) {
        streak++
      } else {
        break
      }
    }
    document.getElementById("streakDays").textContent = streak + " days"

    // Peak hours (simplified)
    document.getElementById("peakHours").textContent = "9AM - 12PM"

    // Week average
    const weekMetrics = metrics.slice(0, 7)
    const weekAvg = Math.round(weekMetrics.reduce((sum, m) => sum + m.productivity_score, 0) / weekMetrics.length)
    document.getElementById("weekAvg").textContent = weekAvg + "%"

    // Usage breakdown
    const recentLogs = logs.slice(0, 100)
    const total = recentLogs.length || 1
    const productive = recentLogs.filter((l) => l.app_category === "productive").length
    const neutral = recentLogs.filter((l) => l.app_category === "neutral").length
    const unproductive = recentLogs.filter((l) => l.app_category === "unproductive").length

    const productivePercent = Math.round((productive / total) * 100)
    const neutralPercent = Math.round((neutral / total) * 100)
    const unproductivePercent = Math.round((unproductive / total) * 100)

    document.getElementById("productivePercent").textContent = productivePercent + "%"
    document.getElementById("neutralPercent").textContent = neutralPercent + "%"
    document.getElementById("unproductivePercent").textContent = unproductivePercent + "%"
    document.getElementById("productiveBar").style.width = productivePercent + "%"
    document.getElementById("neutralBar").style.width = neutralPercent + "%"
    document.getElementById("unproductiveBar").style.width = unproductivePercent + "%"

    // Behavior assessment
    const behavior = employee.work_behavior
    const behaviorData = {
      "High Performer": {
        badge: "Consistent Performer",
        title: "You're crushing it!",
        desc: "Your productivity metrics show excellent focus and consistent high performance. Keep up the great work!",
      },
      Average: {
        badge: "Steady Progress",
        title: "You're on the right track",
        desc: "Your work patterns show balanced productivity. Consider focusing on reducing neutral activities for improvement.",
      },
      "Low Engagement": {
        badge: "Needs Support",
        title: "Let's improve together",
        desc: "Your metrics suggest there might be opportunities to increase focus time. Consider blocking distractions during work hours.",
      },
      "Burnout Risk": {
        badge: "Burnout Watch",
        title: "Time to take a break",
        desc: "Your work hours are very high. Remember to take regular breaks and maintain work-life balance.",
      },
    }

    const bd = behaviorData[behavior] || behaviorData["Average"]
    document.getElementById("behaviorBadge").textContent = bd.badge
    document.getElementById("behaviorTitle").textContent = bd.title
    document.getElementById("behaviorDescription").textContent = bd.desc
  } catch (error) {
    console.error("Error loading insights:", error)
  }
}

// Utilities
function toggleSidebar() {
  document.getElementById("sidebar").classList.toggle("open")
}

function logout() {
  localStorage.removeItem("user")
  window.location.href = "/index.html"
}
