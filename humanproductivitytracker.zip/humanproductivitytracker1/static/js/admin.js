// ============================================
// Admin Dashboard Logic
// Chart.js is loaded via CDN in HTML
// ============================================

const API_BASE = window.location.origin
let currentUser = null
let allEmployees = []
let allMetrics = []
let workforceTrendChart = null
let behaviorChart = null
let teamComparisonChart = null

// ============================================
// Initialization
// ============================================
document.addEventListener("DOMContentLoaded", async () => {
  // Check authentication
  currentUser = JSON.parse(localStorage.getItem("user"))
  if (!currentUser || currentUser.role !== "ADMIN") {
    window.location.href = "/index.html"
    return
  }

  // Update UI with user info
  document.getElementById("userAvatar").textContent = currentUser.avatar
  document.getElementById("userName").textContent = currentUser.name

  // Set current date
  document.getElementById("currentDate").textContent = new Date().toLocaleDateString("en-US", {
    weekday: "long",
    year: "numeric",
    month: "long",
    day: "numeric",
  })

  // Initialize navigation
  initNavigation()

  // Load all data
  await loadAllData()

  // Initialize charts
  initCharts()
})

// ============================================
// Navigation
// ============================================
function initNavigation() {
  const navItems = document.querySelectorAll(".nav-item[data-section]")
  navItems.forEach((item) => {
    item.addEventListener("click", (e) => {
      e.preventDefault()
      const section = item.dataset.section
      switchSection(section)
    })
  })
}

function switchSection(sectionId) {
  // Update nav items
  document.querySelectorAll(".nav-item").forEach((item) => {
    item.classList.remove("active")
    if (item.dataset.section === sectionId) {
      item.classList.add("active")
    }
  })

  // Update sections
  document.querySelectorAll(".section").forEach((section) => {
    section.classList.remove("active")
  })
  document.getElementById(sectionId + "-section").classList.add("active")

  // Update page title
  const titles = {
    overview: "Workforce Overview",
    employees: "Employee Management",
    teams: "Team Analytics",
    reports: "Reports & Export",
  }
  document.getElementById("pageTitle").textContent = titles[sectionId] || "Dashboard"

  // Load section-specific data
  if (sectionId === "teams") {
    loadTeamAnalytics()
  } else if (sectionId === "reports") {
    loadReportsSummary()
  }
}

// ============================================
// Data Loading
// ============================================
async function loadAllData() {
  try {
    // Fetch all employees
    const empRes = await fetch(`${API_BASE}/api/employees`)
    allEmployees = await empRes.json()

    // Fetch all metrics
    const metricsRes = await fetch(`${API_BASE}/api/productivity`)
    allMetrics = await metricsRes.json()

    // Fetch overview
    const overviewRes = await fetch(`${API_BASE}/api/analytics/overview`)
    const overview = await overviewRes.json()

    // Update stats
    document.getElementById("totalEmployees").textContent = overview.total_employees
    document.getElementById("avgProductivity").textContent = overview.avg_productivity + "%"
    document.getElementById("activeTeams").textContent = overview.teams_count
    document.getElementById("burnoutCount").textContent = overview.high_burnout_count

    // Update employee overview table
    updateEmployeeOverviewTable()

    // Populate team filter
    populateTeamFilter()
  } catch (error) {
    console.error("Error loading data:", error)
  }
}

function updateEmployeeOverviewTable() {
  const tbody = document.getElementById("employeeOverviewTable")

  if (allEmployees.length === 0) {
    tbody.innerHTML = '<tr><td colspan="5" class="text-center text-muted">No employees found</td></tr>'
    return
  }

  tbody.innerHTML = allEmployees
    .slice(0, 5)
    .map((emp) => {
      const empMetrics = allMetrics.filter((m) => m.user_id === emp.user_id).slice(0, 7)
      const avgScore =
        empMetrics.length > 0
          ? Math.round(empMetrics.reduce((sum, m) => sum + m.productivity_score, 0) / empMetrics.length)
          : 0

      const latestMetric = empMetrics[0] || {}
      const burnout = latestMetric.burnout_risk || "N/A"

      return `
            <tr class="clickable-row" onclick="viewEmployee(${emp.user_id})">
                <td>
                    <div class="flex items-center gap-2">
                        <div class="avatar avatar-sm">${emp.avatar}</div>
                        <span>${emp.name}</span>
                    </div>
                </td>
                <td><span class="badge badge-primary">${emp.team}</span></td>
                <td>
                    <div class="flex items-center gap-2">
                        <div class="progress-bar" style="width: 80px;">
                            <div class="progress-fill ${avgScore >= 70 ? "green" : avgScore >= 50 ? "yellow" : "red"}" style="width: ${avgScore}%"></div>
                        </div>
                        <span>${avgScore}%</span>
                    </div>
                </td>
                <td><span class="badge badge-${getBehaviorBadgeClass(emp.work_behavior)}">${emp.work_behavior}</span></td>
                <td><span class="badge badge-${burnout === "HIGH" ? "danger" : burnout === "MEDIUM" ? "warning" : "success"}">${burnout}</span></td>
            </tr>
        `
    })
    .join("")
}

function populateTeamFilter() {
  const teams = [...new Set(allEmployees.map((e) => e.team))]
  const select = document.getElementById("teamFilter")
  select.innerHTML =
    '<option value="">All Teams</option>' + teams.map((team) => `<option value="${team}">${team}</option>`).join("")
}

function getBehaviorBadgeClass(behavior) {
  switch (behavior) {
    case "High Performer":
      return "success"
    case "Average":
      return "primary"
    case "Low Engagement":
      return "warning"
    case "Burnout Risk":
      return "danger"
    default:
      return "primary"
  }
}

// ============================================
// Charts - Using global Chart from CDN
// ============================================
async function initCharts() {
  try {
    const trendsRes = await fetch(`${API_BASE}/api/analytics/trends?days=7`)
    const trends = await trendsRes.json()

    const overviewRes = await fetch(`${API_BASE}/api/analytics/overview`)
    const overview = await overviewRes.json()

    // Workforce trend chart
    const trendCtx = document.getElementById("workforceTrendChart").getContext("2d")
    workforceTrendChart = new window.Chart(trendCtx, {
      type: "line",
      data: {
        labels: trends.map((t) => t.day),
        datasets: [
          {
            label: "Avg Productivity",
            data: trends.map((t) => t.productivity_score),
            borderColor: "#2563eb",
            backgroundColor: "rgba(37, 99, 235, 0.1)",
            fill: true,
            tension: 0.4,
          },
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend: { display: false } },
        scales: {
          y: { beginAtZero: true, max: 100, grid: { color: "rgba(0, 0, 0, 0.05)" } },
          x: { grid: { display: false } },
        },
      },
    })

    // Behavior distribution chart
    const behaviors = overview.behaviors || {}
    const behaviorCtx = document.getElementById("behaviorChart").getContext("2d")
    behaviorChart = new window.Chart(behaviorCtx, {
      type: "doughnut",
      data: {
        labels: Object.keys(behaviors),
        datasets: [
          {
            data: Object.values(behaviors),
            backgroundColor: ["#10b981", "#3b82f6", "#f59e0b", "#ef4444"],
            borderWidth: 0,
          },
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { position: "bottom" },
        },
      },
    })
  } catch (error) {
    console.error("Error initializing charts:", error)
  }
}

// ============================================
// Employees Section
// ============================================
function filterEmployees() {
  const teamFilter = document.getElementById("teamFilter").value
  const behaviorFilter = document.getElementById("behaviorFilter").value

  let filtered = allEmployees

  if (teamFilter) {
    filtered = filtered.filter((e) => e.team === teamFilter)
  }

  if (behaviorFilter) {
    filtered = filtered.filter((e) => e.work_behavior === behaviorFilter)
  }

  updateAllEmployeesTable(filtered)
}

function updateAllEmployeesTable(employees) {
  const tbody = document.getElementById("allEmployeesTable")

  if (employees.length === 0) {
    tbody.innerHTML = '<tr><td colspan="6" class="text-center text-muted">No employees match the filter</td></tr>'
    return
  }

  tbody.innerHTML = employees
    .map((emp) => {
      const empMetrics = allMetrics.filter((m) => m.user_id === emp.user_id).slice(0, 7)
      const avgScore =
        empMetrics.length > 0
          ? Math.round(empMetrics.reduce((sum, m) => sum + m.productivity_score, 0) / empMetrics.length)
          : 0

      return `
            <tr class="clickable-row" onclick="viewEmployee(${emp.user_id})">
                <td>
                    <div class="flex items-center gap-2">
                        <div class="avatar avatar-sm">${emp.avatar}</div>
                        <span>${emp.name}</span>
                    </div>
                </td>
                <td>${emp.email}</td>
                <td><span class="badge badge-primary">${emp.team}</span></td>
                <td>
                    <div class="flex items-center gap-2">
                        <div class="progress-bar" style="width: 60px;">
                            <div class="progress-fill ${avgScore >= 70 ? "green" : avgScore >= 50 ? "yellow" : "red"}" style="width: ${avgScore}%"></div>
                        </div>
                        <span>${avgScore}%</span>
                    </div>
                </td>
                <td><span class="badge badge-${getBehaviorBadgeClass(emp.work_behavior)}">${emp.work_behavior}</span></td>
                <td><span class="status-dot ${avgScore >= 50 ? "active" : "inactive"}"></span> ${avgScore >= 50 ? "Active" : "Inactive"}</td>
            </tr>
        `
    })
    .join("")
}

// ============================================
// Employee Detail Modal
// ============================================
function viewEmployee(userId) {
  const employee = allEmployees.find((e) => e.user_id === userId)
  if (!employee) return

  const empMetrics = allMetrics.filter((m) => m.user_id === userId).slice(0, 7)
  const avgScore =
    empMetrics.length > 0
      ? Math.round(empMetrics.reduce((sum, m) => sum + m.productivity_score, 0) / empMetrics.length)
      : 0

  const latestMetric = empMetrics[0] || {}
  const productiveTime = latestMetric.productive_minutes || 0
  const neutralTime = latestMetric.neutral_minutes || 0
  const unproductiveTime = latestMetric.unproductive_minutes || 0
  const totalTime = productiveTime + neutralTime + unproductiveTime

  document.getElementById("modalEmployeeName").textContent = employee.name

  document.getElementById("modalContent").innerHTML = `
        <div class="employee-detail">
            <div class="profile-header">
                <div class="avatar">${employee.avatar}</div>
                <div class="profile-info">
                    <h4>${employee.name}</h4>
                    <p>${employee.email}</p>
                    <div class="flex gap-2 mt-2">
                        <span class="badge badge-primary">${employee.team}</span>
                        <span class="badge badge-${getBehaviorBadgeClass(employee.work_behavior)}">${employee.work_behavior}</span>
                    </div>
                </div>
            </div>
            
            <div class="metrics-grid">
                <div class="metric-item">
                    <div class="metric-label">Avg Productivity (7d)</div>
                    <div class="metric-value" style="color: ${avgScore >= 70 ? "var(--success)" : avgScore >= 50 ? "var(--warning)" : "var(--danger)"}">${avgScore}%</div>
                </div>
                <div class="metric-item">
                    <div class="metric-label">Burnout Risk</div>
                    <div class="metric-value">${latestMetric.burnout_risk || "N/A"}</div>
                </div>
                <div class="metric-item">
                    <div class="metric-label">Productive Time</div>
                    <div class="metric-value" style="color: var(--success)">${Math.round(productiveTime / 60)}h ${productiveTime % 60}m</div>
                </div>
                <div class="metric-item">
                    <div class="metric-label">Total Logged Time</div>
                    <div class="metric-value">${Math.round(totalTime / 60)}h ${totalTime % 60}m</div>
                </div>
            </div>
            
            <div>
                <h4 class="mb-2">Time Distribution (Today)</h4>
                <div class="usage-breakdown">
                    <div class="usage-category">
                        <div class="category-header">
                            <span class="category-dot productive"></span>
                            <span>Productive</span>
                            <span class="category-percentage">${totalTime > 0 ? Math.round((productiveTime / totalTime) * 100) : 0}%</span>
                        </div>
                        <div class="progress-bar">
                            <div class="progress-fill green" style="width: ${totalTime > 0 ? (productiveTime / totalTime) * 100 : 0}%"></div>
                        </div>
                    </div>
                    <div class="usage-category">
                        <div class="category-header">
                            <span class="category-dot neutral"></span>
                            <span>Neutral</span>
                            <span class="category-percentage">${totalTime > 0 ? Math.round((neutralTime / totalTime) * 100) : 0}%</span>
                        </div>
                        <div class="progress-bar">
                            <div class="progress-fill yellow" style="width: ${totalTime > 0 ? (neutralTime / totalTime) * 100 : 0}%"></div>
                        </div>
                    </div>
                    <div class="usage-category">
                        <div class="category-header">
                            <span class="category-dot unproductive"></span>
                            <span>Unproductive</span>
                            <span class="category-percentage">${totalTime > 0 ? Math.round((unproductiveTime / totalTime) * 100) : 0}%</span>
                        </div>
                        <div class="progress-bar">
                            <div class="progress-fill red" style="width: ${totalTime > 0 ? (unproductiveTime / totalTime) * 100 : 0}%"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    `

  document.getElementById("employeeModal").classList.remove("hidden")
}

function closeModal() {
  document.getElementById("employeeModal").classList.add("hidden")
}

// ============================================
// Team Analytics
// ============================================
async function loadTeamAnalytics() {
  try {
    const res = await fetch(`${API_BASE}/api/analytics/team`)
    const teams = await res.json()

    const container = document.getElementById("teamCards")
    container.innerHTML = teams
      .map(
        (team) => `
            <div class="card team-card">
                <div class="team-header">
                    <span class="team-name">${team.team}</span>
                    <span class="team-members">${team.members} members</span>
                </div>
                <div class="team-score">${team.avg_score}%</div>
                <div class="progress-bar">
                    <div class="progress-fill ${team.avg_score >= 70 ? "green" : team.avg_score >= 50 ? "yellow" : "red"}" style="width: ${team.avg_score}%"></div>
                </div>
                <div class="team-behaviors">
                    ${Object.entries(team.behaviors)
                      .map(
                        ([behavior, count]) =>
                          `<span class="badge badge-${getBehaviorBadgeClass(behavior)}">${behavior}: ${count}</span>`,
                      )
                      .join("")}
                </div>
            </div>
        `,
      )
      .join("")

    const ctx = document.getElementById("teamComparisonChart").getContext("2d")
    if (teamComparisonChart) {
      teamComparisonChart.destroy()
    }

    teamComparisonChart = new window.Chart(ctx, {
      type: "bar",
      data: {
        labels: teams.map((t) => t.team),
        datasets: [
          {
            label: "Avg Productivity Score",
            data: teams.map((t) => t.avg_score),
            backgroundColor: teams.map((t) =>
              t.avg_score >= 70 ? "#10b981" : t.avg_score >= 50 ? "#f59e0b" : "#ef4444",
            ),
            borderRadius: 8,
          },
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend: { display: false } },
        scales: {
          y: { beginAtZero: true, max: 100 },
          x: { grid: { display: false } },
        },
      },
    })
  } catch (error) {
    console.error("Error loading team analytics:", error)
  }
}

// ============================================
// Reports
// ============================================
function loadReportsSummary() {
  document.getElementById("totalRecords").textContent = allMetrics.length + " records"

  const dates = allMetrics.map((m) => m.date).sort()
  if (dates.length > 0) {
    const startDate = new Date(dates[0]).toLocaleDateString("en-US", { month: "short", day: "numeric" })
    const endDate = new Date(dates[dates.length - 1]).toLocaleDateString("en-US", {
      month: "short",
      day: "numeric",
      year: "numeric",
    })
    document.getElementById("dateRange").textContent = `${startDate} - ${endDate}`
  }
}

function generateReport(type) {
  let csvContent = ""
  let filename = ""

  switch (type) {
    case "productivity":
      csvContent =
        "user_id,date,productivity_score,burnout_risk,productive_minutes,neutral_minutes,unproductive_minutes\n"
      allMetrics.forEach((m) => {
        csvContent += `${m.user_id},${m.date},${m.productivity_score},${m.burnout_risk},${m.productive_minutes},${m.neutral_minutes},${m.unproductive_minutes}\n`
      })
      filename = "productivity_report.csv"
      break

    case "attendance":
      csvContent = "user_id,name,team,date,login_time,logout_time,total_minutes\n"
      allEmployees.forEach((emp) => {
        csvContent += `${emp.user_id},${emp.name},${emp.team},2024-01-15,09:00,18:00,540\n`
      })
      filename = "attendance_report.csv"
      break

    case "behavior":
      csvContent = "user_id,name,email,team,work_behavior,avg_productivity\n"
      allEmployees.forEach((emp) => {
        const empMetrics = allMetrics.filter((m) => m.user_id === emp.user_id).slice(0, 7)
        const avgScore =
          empMetrics.length > 0
            ? Math.round(empMetrics.reduce((sum, m) => sum + m.productivity_score, 0) / empMetrics.length)
            : 0
        csvContent += `${emp.user_id},${emp.name},${emp.email},${emp.team},${emp.work_behavior},${avgScore}\n`
      })
      filename = "behavior_analysis.csv"
      break

    case "team":
      csvContent = "team,members,avg_score\n"
      const teams = {}
      allEmployees.forEach((emp) => {
        if (!teams[emp.team]) teams[emp.team] = { members: 0, totalScore: 0 }
        teams[emp.team].members++
        const empMetrics = allMetrics.filter((m) => m.user_id === emp.user_id).slice(0, 7)
        const avgScore =
          empMetrics.length > 0 ? empMetrics.reduce((sum, m) => sum + m.productivity_score, 0) / empMetrics.length : 0
        teams[emp.team].totalScore += avgScore
      })
      Object.entries(teams).forEach(([team, data]) => {
        csvContent += `${team},${data.members},${Math.round(data.totalScore / data.members)}\n`
      })
      filename = "team_analytics.csv"
      break
  }

  const blob = new Blob([csvContent], { type: "text/csv" })
  const url = URL.createObjectURL(blob)
  const a = document.createElement("a")
  a.href = url
  a.download = filename
  document.body.appendChild(a)
  a.click()
  document.body.removeChild(a)
  URL.revokeObjectURL(url)

  alert(`Report "${filename}" downloaded successfully!`)
}

// ============================================
// Utilities
// ============================================
function toggleSidebar() {
  document.getElementById("sidebar").classList.toggle("open")
}

function logout() {
  localStorage.removeItem("user")
  window.location.href = "/index.html"
}
