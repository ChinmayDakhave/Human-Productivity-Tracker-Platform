// ============================================
// Login Page Logic
// ============================================

const API_BASE = window.location.origin

document.addEventListener("DOMContentLoaded", () => {
  // Check if already logged in
  const user = JSON.parse(localStorage.getItem("user"))
  if (user) {
    redirectToDashboard(user.role)
  }

  // Handle form submission
  const loginForm = document.getElementById("loginForm")
  loginForm.addEventListener("submit", handleLogin)
})

async function handleLogin(e) {
  e.preventDefault()

  const email = document.getElementById("email").value
  const password = document.getElementById("password").value
  const errorMessage = document.getElementById("errorMessage")
  const submitBtn = e.target.querySelector('button[type="submit"]')

  // Disable button during request
  submitBtn.disabled = true
  submitBtn.innerHTML = "<span>Signing in...</span>"

  try {
    const response = await fetch(`${API_BASE}/api/login`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ email, password }),
    })

    const data = await response.json()

    if (data.success) {
      // Store user data
      localStorage.setItem("user", JSON.stringify(data.user))

      // Redirect based on role
      redirectToDashboard(data.user.role)
    } else {
      showError(data.message || "Invalid credentials")
    }
  } catch (error) {
    showError("Connection error. Please try again.")
    console.error("Login error:", error)
  } finally {
    submitBtn.disabled = false
    submitBtn.innerHTML = `
            <span>Sign In</span>
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M5 12h14M12 5l7 7-7 7"/>
            </svg>
        `
  }
}

function showError(message) {
  const errorElement = document.getElementById("errorMessage")
  errorElement.textContent = message
  errorElement.classList.remove("hidden")

  setTimeout(() => {
    errorElement.classList.add("hidden")
  }, 5000)
}

function fillCredentials(email, password) {
  document.getElementById("email").value = email
  document.getElementById("password").value = password
}

function redirectToDashboard(role) {
  if (role === "ADMIN") {
    window.location.href = "/admin.html"
  } else {
    window.location.href = "/employee.html"
  }
}
