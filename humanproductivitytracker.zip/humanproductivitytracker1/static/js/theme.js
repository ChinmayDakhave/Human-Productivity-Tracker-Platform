// ============================================
// Theme Management
// ============================================

function initTheme() {
  const savedTheme = localStorage.getItem("theme") || "light"
  setTheme(savedTheme)
}

function setTheme(theme) {
  document.body.classList.remove("light-mode", "dark-mode")
  document.body.classList.add(theme + "-mode")
  localStorage.setItem("theme", theme)
  updateThemeIcons(theme)
}

function toggleTheme() {
  const currentTheme = localStorage.getItem("theme") || "light"
  const newTheme = currentTheme === "light" ? "dark" : "light"
  setTheme(newTheme)
}

function updateThemeIcons(theme) {
  const sunIcon = document.getElementById("sunIcon")
  const moonIcon = document.getElementById("moonIcon")

  if (sunIcon && moonIcon) {
    if (theme === "dark") {
      sunIcon.classList.add("hidden")
      moonIcon.classList.remove("hidden")
    } else {
      sunIcon.classList.remove("hidden")
      moonIcon.classList.add("hidden")
    }
  }
}

// Initialize theme on page load
document.addEventListener("DOMContentLoaded", initTheme)
