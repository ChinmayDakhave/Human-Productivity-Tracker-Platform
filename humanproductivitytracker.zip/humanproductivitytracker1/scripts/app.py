from flask import Flask, jsonify, request, send_from_directory
from flask_cors import CORS
from datetime import datetime, timedelta
import random
import json
import os

app = Flask(__name__, static_folder='../static', static_url_path='')
CORS(app)

# ============================================
# SYNTHETIC DATA - In-Memory Storage
# ============================================

# Employee Data
employees = [
    {"user_id": 1, "name": "Amit Sharma", "email": "amit@company.com", "password": "demo123", "role": "EMPLOYEE", "team": "Backend", "work_behavior": "High Performer", "avatar": "AS"},
    {"user_id": 2, "name": "Priya Patel", "email": "priya@company.com", "password": "demo123", "role": "EMPLOYEE", "team": "Frontend", "work_behavior": "Average", "avatar": "PP"},
    {"user_id": 3, "name": "Rahul Kumar", "email": "rahul@company.com", "password": "demo123", "role": "EMPLOYEE", "team": "QA", "work_behavior": "Burnout Risk", "avatar": "RK"},
    {"user_id": 4, "name": "Sneha Gupta", "email": "sneha@company.com", "password": "demo123", "role": "EMPLOYEE", "team": "Design", "work_behavior": "High Performer", "avatar": "SG"},
    {"user_id": 5, "name": "Vikram Singh", "email": "vikram@company.com", "password": "demo123", "role": "EMPLOYEE", "team": "Backend", "work_behavior": "Low Engagement", "avatar": "VS"},
    {"user_id": 6, "name": "Ananya Roy", "email": "ananya@company.com", "password": "demo123", "role": "EMPLOYEE", "team": "HR", "work_behavior": "Average", "avatar": "AR"},
    {"user_id": 7, "name": "Karan Mehta", "email": "karan@company.com", "password": "demo123", "role": "EMPLOYEE", "team": "Frontend", "work_behavior": "High Performer", "avatar": "KM"},
    {"user_id": 8, "name": "Deepika Nair", "email": "deepika@company.com", "password": "demo123", "role": "EMPLOYEE", "team": "QA", "work_behavior": "Average", "avatar": "DN"},
    {"user_id": 9, "name": "Admin User", "email": "admin@company.com", "password": "admin123", "role": "ADMIN", "team": "Management", "work_behavior": "N/A", "avatar": "AD"},
    {"user_id": 10, "name": "HR Manager", "email": "hr@company.com", "password": "hr123", "role": "ADMIN", "team": "HR", "work_behavior": "N/A", "avatar": "HR"},
]

# App Categories
productive_apps = ["VS Code", "Excel", "Jira", "Slack (Work)", "Google Docs", "Figma", "IntelliJ", "Postman", "Terminal", "Zoom (Meeting)"]
neutral_apps = ["Chrome", "Outlook", "Teams", "Notion", "Calendar", "Notes"]
unproductive_apps = ["YouTube", "Twitter", "Instagram", "Reddit", "Netflix", "Gaming"]

# Task Categories
task_categories = ["Development", "Documentation", "Communication", "Design", "Testing", "Research", "Meeting", "Administrative"]

# Generate synthetic work sessions
def generate_work_sessions():
    sessions = []
    for emp in employees:
        if emp["role"] == "ADMIN":
            continue
        for days_ago in range(30):
            date = (datetime.now() - timedelta(days=days_ago)).strftime("%Y-%m-%d")
            
            # Vary login times based on behavior
            if emp["work_behavior"] == "High Performer":
                login_hour = random.randint(8, 9)
                work_hours = random.randint(8, 10)
            elif emp["work_behavior"] == "Burnout Risk":
                login_hour = random.randint(7, 8)
                work_hours = random.randint(10, 12)
            elif emp["work_behavior"] == "Low Engagement":
                login_hour = random.randint(9, 10)
                work_hours = random.randint(5, 7)
            else:
                login_hour = random.randint(9, 10)
                work_hours = random.randint(7, 9)
            
            login_time = f"{login_hour:02d}:{random.randint(0, 59):02d}"
            logout_hour = login_hour + work_hours
            logout_time = f"{logout_hour:02d}:{random.randint(0, 59):02d}"
            
            sessions.append({
                "user_id": emp["user_id"],
                "date": date,
                "login_time": login_time,
                "logout_time": logout_time,
                "total_minutes": work_hours * 60 + random.randint(-30, 30)
            })
    return sessions

# Generate synthetic app usage logs
def generate_app_usage():
    logs = []
    for emp in employees:
        if emp["role"] == "ADMIN":
            continue
        for days_ago in range(30):
            date = (datetime.now() - timedelta(days=days_ago)).strftime("%Y-%m-%d")
            
            # App usage distribution based on behavior
            if emp["work_behavior"] == "High Performer":
                app_weights = [(productive_apps, 70), (neutral_apps, 25), (unproductive_apps, 5)]
            elif emp["work_behavior"] == "Burnout Risk":
                app_weights = [(productive_apps, 80), (neutral_apps, 15), (unproductive_apps, 5)]
            elif emp["work_behavior"] == "Low Engagement":
                app_weights = [(productive_apps, 30), (neutral_apps, 30), (unproductive_apps, 40)]
            else:
                app_weights = [(productive_apps, 50), (neutral_apps, 35), (unproductive_apps, 15)]
            
            # Generate 5-10 app usage entries per day
            num_entries = random.randint(5, 10)
            current_hour = random.randint(9, 10)
            
            for _ in range(num_entries):
                # Select app category based on weights
                rand = random.randint(1, 100)
                cumulative = 0
                selected_apps = productive_apps
                for apps, weight in app_weights:
                    cumulative += weight
                    if rand <= cumulative:
                        selected_apps = apps
                        break
                
                app = random.choice(selected_apps)
                duration = random.randint(15, 120)
                start_time = f"{current_hour:02d}:{random.randint(0, 59):02d}"
                end_hour = current_hour + (duration // 60)
                end_time = f"{end_hour:02d}:{(random.randint(0, 59)):02d}"
                
                # Determine category based on app
                if app in productive_apps:
                    category = "productive"
                elif app in neutral_apps:
                    category = "neutral"
                else:
                    category = "unproductive"
                
                logs.append({
                    "user_id": emp["user_id"],
                    "date": date,
                    "application": app,
                    "start_time": start_time,
                    "end_time": end_time,
                    "duration": duration,
                    "task_description": f"Working on {random.choice(task_categories).lower()} tasks",
                    "task_category": random.choice(task_categories),
                    "app_category": category
                })
                
                current_hour = min(current_hour + 1, 18)
    return logs

# Generate productivity metrics
def generate_productivity_metrics():
    metrics = []
    for emp in employees:
        if emp["role"] == "ADMIN":
            continue
        for days_ago in range(30):
            date = (datetime.now() - timedelta(days=days_ago)).strftime("%Y-%m-%d")
            
            if emp["work_behavior"] == "High Performer":
                score = random.randint(80, 95)
                burnout = "LOW"
                productive = random.randint(300, 420)
                neutral = random.randint(60, 120)
                unproductive = random.randint(10, 40)
            elif emp["work_behavior"] == "Burnout Risk":
                score = random.randint(70, 85)
                burnout = "HIGH"
                productive = random.randint(400, 540)
                neutral = random.randint(60, 90)
                unproductive = random.randint(20, 40)
            elif emp["work_behavior"] == "Low Engagement":
                score = random.randint(35, 55)
                burnout = "LOW"
                productive = random.randint(120, 200)
                neutral = random.randint(100, 150)
                unproductive = random.randint(100, 180)
            else:
                score = random.randint(55, 75)
                burnout = "MEDIUM" if random.random() > 0.7 else "LOW"
                productive = random.randint(220, 320)
                neutral = random.randint(80, 140)
                unproductive = random.randint(40, 80)
            
            metrics.append({
                "user_id": emp["user_id"],
                "date": date,
                "productivity_score": score,
                "burnout_risk": burnout,
                "productive_minutes": productive,
                "neutral_minutes": neutral,
                "unproductive_minutes": unproductive
            })
    return metrics

# Initialize data
work_sessions = generate_work_sessions()
app_usage_logs = generate_app_usage()
productivity_metrics = generate_productivity_metrics()

# In-memory storage for new logs (today's manual entries)
today_logs = []

# ============================================
# API ROUTES
# ============================================

@app.route('/')
def serve_index():
    return send_from_directory('../static', 'index.html')

@app.route('/<path:path>')
def serve_static(path):
    return send_from_directory('../static', path)

# Authentication
@app.route('/api/login', methods=['POST'])
def login():
    data = request.json
    email = data.get('email', '')
    password = data.get('password', '')
    
    for emp in employees:
        if emp['email'] == email and emp['password'] == password:
            return jsonify({
                "success": True,
                "user": {
                    "user_id": emp["user_id"],
                    "name": emp["name"],
                    "email": emp["email"],
                    "role": emp["role"],
                    "team": emp["team"],
                    "avatar": emp["avatar"]
                }
            })
    
    return jsonify({"success": False, "message": "Invalid credentials"}), 401

# Get all employees (Admin only)
@app.route('/api/employees', methods=['GET'])
def get_employees():
    return jsonify([{k: v for k, v in emp.items() if k != 'password'} for emp in employees if emp['role'] == 'EMPLOYEE'])

# Get employee by ID
@app.route('/api/employees/<int:user_id>', methods=['GET'])
def get_employee(user_id):
    for emp in employees:
        if emp['user_id'] == user_id:
            return jsonify({k: v for k, v in emp.items() if k != 'password'})
    return jsonify({"error": "Employee not found"}), 404

# Get work sessions
@app.route('/api/sessions', methods=['GET'])
def get_sessions():
    user_id = request.args.get('user_id', type=int)
    if user_id:
        return jsonify([s for s in work_sessions if s['user_id'] == user_id])
    return jsonify(work_sessions)

# Get app usage logs
@app.route('/api/app-usage', methods=['GET'])
def get_app_usage():
    user_id = request.args.get('user_id', type=int)
    date = request.args.get('date')
    
    filtered = app_usage_logs
    if user_id:
        filtered = [l for l in filtered if l['user_id'] == user_id]
    if date:
        filtered = [l for l in filtered if l['date'] == date]
    
    return jsonify(filtered)

# Log new app usage (Employee manual entry)
@app.route('/api/app-usage', methods=['POST'])
def log_app_usage():
    data = request.json
    
    # Determine app category
    app_name = data.get('application', '')
    if app_name in productive_apps:
        category = "productive"
    elif app_name in neutral_apps:
        category = "neutral"
    else:
        category = "unproductive"
    
    new_log = {
        "user_id": data.get('user_id'),
        "date": data.get('date', datetime.now().strftime("%Y-%m-%d")),
        "application": app_name,
        "start_time": data.get('start_time'),
        "end_time": data.get('end_time'),
        "duration": data.get('duration'),
        "task_description": data.get('task_description'),
        "task_category": data.get('task_category'),
        "app_category": category
    }
    
    app_usage_logs.append(new_log)
    today_logs.append(new_log)
    
    return jsonify({"success": True, "log": new_log})

# Get productivity metrics
@app.route('/api/productivity', methods=['GET'])
def get_productivity():
    user_id = request.args.get('user_id', type=int)
    if user_id:
        return jsonify([m for m in productivity_metrics if m['user_id'] == user_id])
    return jsonify(productivity_metrics)

# Get team analytics (Admin)
@app.route('/api/analytics/team', methods=['GET'])
def get_team_analytics():
    teams = {}
    for emp in employees:
        if emp['role'] == 'ADMIN':
            continue
        team = emp['team']
        if team not in teams:
            teams[team] = {"team": team, "members": 0, "total_score": 0, "behaviors": {}}
        teams[team]["members"] += 1
        
        # Get average score for this employee
        emp_metrics = [m for m in productivity_metrics if m['user_id'] == emp['user_id']]
        if emp_metrics:
            avg_score = sum(m['productivity_score'] for m in emp_metrics) / len(emp_metrics)
            teams[team]["total_score"] += avg_score
        
        behavior = emp['work_behavior']
        teams[team]["behaviors"][behavior] = teams[team]["behaviors"].get(behavior, 0) + 1
    
    result = []
    for team_name, data in teams.items():
        result.append({
            "team": team_name,
            "members": data["members"],
            "avg_score": round(data["total_score"] / data["members"], 1) if data["members"] > 0 else 0,
            "behaviors": data["behaviors"]
        })
    
    return jsonify(result)

# Get workforce overview (Admin)
@app.route('/api/analytics/overview', methods=['GET'])
def get_overview():
    total_employees = len([e for e in employees if e['role'] == 'EMPLOYEE'])
    
    # Calculate overall metrics
    all_scores = [m['productivity_score'] for m in productivity_metrics]
    avg_productivity = round(sum(all_scores) / len(all_scores), 1) if all_scores else 0
    
    # Count behavior types
    behaviors = {}
    for emp in employees:
        if emp['role'] == 'EMPLOYEE':
            b = emp['work_behavior']
            behaviors[b] = behaviors.get(b, 0) + 1
    
    # Burnout risk count
    high_burnout = len([e for e in employees if e['work_behavior'] == 'Burnout Risk'])
    
    return jsonify({
        "total_employees": total_employees,
        "avg_productivity": avg_productivity,
        "behaviors": behaviors,
        "high_burnout_count": high_burnout,
        "teams_count": len(set(e['team'] for e in employees if e['role'] == 'EMPLOYEE'))
    })

# Get productivity trends (last 7 days)
@app.route('/api/analytics/trends', methods=['GET'])
def get_trends():
    user_id = request.args.get('user_id', type=int)
    days = request.args.get('days', default=7, type=int)
    
    trends = []
    for days_ago in range(days - 1, -1, -1):
        date = (datetime.now() - timedelta(days=days_ago)).strftime("%Y-%m-%d")
        
        if user_id:
            day_metrics = [m for m in productivity_metrics if m['date'] == date and m['user_id'] == user_id]
        else:
            day_metrics = [m for m in productivity_metrics if m['date'] == date]
        
        if day_metrics:
            avg_score = sum(m['productivity_score'] for m in day_metrics) / len(day_metrics)
            avg_productive = sum(m['productive_minutes'] for m in day_metrics) / len(day_metrics)
            avg_neutral = sum(m['neutral_minutes'] for m in day_metrics) / len(day_metrics)
            avg_unproductive = sum(m['unproductive_minutes'] for m in day_metrics) / len(day_metrics)
        else:
            avg_score = 0
            avg_productive = 0
            avg_neutral = 0
            avg_unproductive = 0
        
        trends.append({
            "date": date,
            "day": (datetime.now() - timedelta(days=days_ago)).strftime("%a"),
            "productivity_score": round(avg_score, 1),
            "productive_minutes": round(avg_productive),
            "neutral_minutes": round(avg_neutral),
            "unproductive_minutes": round(avg_unproductive)
        })
    
    return jsonify(trends)

# Get app categories
@app.route('/api/app-categories', methods=['GET'])
def get_app_categories():
    return jsonify({
        "productive": productive_apps,
        "neutral": neutral_apps,
        "unproductive": unproductive_apps,
        "task_categories": task_categories
    })

# Get today's logs for employee
@app.route('/api/today-logs/<int:user_id>', methods=['GET'])
def get_today_logs(user_id):
    today = datetime.now().strftime("%Y-%m-%d")
    logs = [l for l in app_usage_logs if l['user_id'] == user_id and l['date'] == today]
    return jsonify(logs)

# Start work session
@app.route('/api/sessions/start', methods=['POST'])
def start_session():
    data = request.json
    session = {
        "user_id": data.get('user_id'),
        "date": datetime.now().strftime("%Y-%m-%d"),
        "login_time": datetime.now().strftime("%H:%M"),
        "logout_time": None,
        "total_minutes": 0
    }
    work_sessions.append(session)
    return jsonify({"success": True, "session": session})

# End work session
@app.route('/api/sessions/end', methods=['POST'])
def end_session():
    data = request.json
    user_id = data.get('user_id')
    today = datetime.now().strftime("%Y-%m-%d")
    
    for session in work_sessions:
        if session['user_id'] == user_id and session['date'] == today and session['logout_time'] is None:
            session['logout_time'] = datetime.now().strftime("%H:%M")
            # Calculate total minutes
            login = datetime.strptime(session['login_time'], "%H:%M")
            logout = datetime.strptime(session['logout_time'], "%H:%M")
            session['total_minutes'] = int((logout - login).total_seconds() / 60)
            return jsonify({"success": True, "session": session})
    
    return jsonify({"success": False, "message": "No active session found"}), 404

if __name__ == '__main__':
    app.run(debug=True, port=5000)
