# Human Productivity Tracker Based on Digital Behaviour

## A Project Report
**Submitted in partial fulfillment of the Requirements for the award of the Degree of**

### BACHELOR OF SCIENCE DATA SCIENCE

**By**

**[Your Name]**  
**[Your Seat No.]**

**Under the esteemed guidance of**  
**[Prof. Name]**  
*Assistant Professor*

---

**DEPARTMENT OF DATA SCIENCE**  
**PILLAI HOC COLLEGE OF ARTS, SCIENCE AND COMMERCE,**  
**(Autonomous) RASAYANI**

**RASAYANI RAIGAD DIST. KHALAPUR – 410 207**  
**MAHARASHTRA**  
**2025-26**

---

## PILLAI HOC COLLEGE OF ARTS, SCIENCE AND COMMERCE, (Autonomous) RASAYANI

**RASAYANI RAIGAD DIST. KHALAPUR – 410 207**  
**MAHARASHTRA**

### DEPARTMENT OF DATA SCIENCE

## CERTIFICATE

This is to certify that the project entitled, **"Human Productivity Tracker Based on Digital Behaviour"**, is Bonafide work of **[Your Name]** bearing Seat No: **[Your Seat No.]** submitted in partial fulfillment of the requirements for the award of degree of BACHELOR OF SCIENCE in DATA SCIENCE from University of Mumbai.

---

**Internal Guide** &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; **Coordinator**

---

**External Examiner**

---

**Date:** &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; **College Seal:**

---

## ABSTRACT

This project presents the development of an interactive **Human Productivity Tracker** that monitors and analyzes employee digital behavior to provide insights into productivity patterns, work habits, and burnout risk assessment. The system enables organizations to track employee work sessions, application usage, and productivity metrics through a comprehensive web-based dashboard.

The platform implements a dual-interface system with separate dashboards for Administrators and Employees. Administrators can view workforce-wide analytics, team performance comparisons, behavior distributions, and generate detailed reports. Employees can log their daily activities, track personal productivity scores, view historical trends, and access personalized insights about their work patterns.

Key features include:
- **Role-based Authentication System**: Secure login with differentiated access for Admins and Employees
- **Activity Logging Module**: Manual submission of application usage categorized as productive, neutral, or unproductive
- **Real-time Analytics Dashboard**: Interactive charts showing productivity trends, behavior distributions, and team comparisons
- **Burnout Risk Assessment**: Automated calculation of burnout risk levels based on work patterns
- **Report Generation**: CSV export functionality for productivity, attendance, behavior, and team analytics reports

The dashboard emphasizes user privacy by clearly stating that no automatic computer tracking occurs - all logs are manually submitted. This prototype demonstrates the potential of digital behavior analytics in HR management while maintaining ethical data collection practices.

---

## ACKNOWLEDGEMENT

I would like to express my sincere gratitude to everyone who supported me throughout the course of my project. First and foremost, I would like to thank my **Project guide, Prof. [Guide Name]**, for their invaluable guidance, insightful feedback, and continuous encouragement during the development of this project. Their expertise and advice have been essential in helping me navigate through challenges and achieve the project's objectives.

I would also like to thank all individuals who contributed to the successful completion of this project. A heartfelt thanks to our **Principal, Dr. [Principal Name]**, and our **Department Coordinator, Prof. [Coordinator Name]**, for their unwavering support and motivation throughout this academic endeavour.

I am also grateful to the faculty members of **B.Sc. Data Science at Pillai HOC College of Arts, Science & Commerce**, for providing me with the resources and a conducive environment necessary to carry out this project successfully. Special thanks to the Lab Assistants and my fellow colleagues for their technical support and assistance in troubleshooting issues encountered during implementation.

This project would not have been possible without the valuable contributions of the open-source community. I extend my sincere appreciation to the developers and contributors of the tools and libraries used in this project, such as **Chart.js, JavaScript, HTML5, CSS3, and REST APIs**, which played a pivotal role in building the Human Productivity Tracker Dashboard.

Thank you to everyone who contributed, directly or indirectly, to the successful completion of this project.

---

## DECLARATION

I hereby declare that the project entitled, **"Human Productivity Tracker Based on Digital Behaviour"** done at Pillai HOC College Of Arts Science And Commerce, has not been in any case duplicated to submit to any other university for the award of any degree. To the best of my knowledge other than me, no one has submitted to any other university.

The project is done in partial fulfilment of the requirements for the award of degree of BACHELOR OF SCIENCE (DATA SCIENCE) to be submitted as final semester project as part of our curriculum.

---

**Signature of Student**

**[Your Name]**

---

## PROFORMA FOR THE APPROVAL PROJECT PROPOSAL

**PRN No:** .................................. **Seat No:** ........................

1. **Name of the Student:** ....................................................................................

2. **Title of the Project:** Human Productivity Tracker Based on Digital Behaviour

3. **Name of the Guide:** ................................................................................

4. **Teaching experience of the Guide:** .......................................

5. **Is this your first submission?** Yes ☐ No ☐

---

........................... .....................  
**Signature of the student** &emsp;&emsp; **Signature of the Guide**  
**Date:** ..................... &emsp;&emsp;&emsp;&emsp;&emsp; **Date:** ..................

---

**Signature of the Coordinator**  
**Date:** .....................

---

## TABLE OF CONTENTS

### Chapter 1: Introduction
- 1.1 Background &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; 01
- 1.2 Problem Definition &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; 01
- 1.3 Objectives &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; 02
- 1.4 Purpose &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; 02
- 1.5 Scope &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; 03
- 1.6 Applicability &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; 03
- 1.7 Achievements &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; 03
- 1.8 Organisation of Report &emsp;&emsp;&emsp;&emsp;&emsp; 04

### Chapter 2: Data Description
- 2.1 Data Source and Extraction &emsp;&emsp;&emsp;&emsp; 06
- 2.2 Explaining the Data &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; 06
- 2.3 Data Management and Modeling &emsp;&emsp; 07
  - 2.3.1 Data Management Approach &emsp;&emsp; 07
  - 2.3.2 Data Model Schema &emsp;&emsp;&emsp;&emsp;&emsp; 07
- 2.4 Data Pre-processing &emsp;&emsp;&emsp;&emsp;&emsp;&emsp; 08
- 2.5 Data Engineering &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; 08
- 2.6 Data Analysis &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; 09
- 2.7 Data Visualization &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; 09

### Chapter 3: Models and Algorithms
- 3.1 Productivity Score Calculation &emsp;&emsp;&emsp; 12
- 3.2 Burnout Risk Assessment &emsp;&emsp;&emsp;&emsp;&emsp; 12
- 3.3 Behavior Classification &emsp;&emsp;&emsp;&emsp;&emsp;&emsp; 13
- 3.4 Technologies Used &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; 13
- 3.5 Evaluation Methods &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; 14
- 3.6 Deployment &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; 14

### Chapter 4: Project Analysis
- 4.1 System Design &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; 15
- 4.2 Packages Used and Implementation &emsp; 16
- 4.3 Code Flow and Logic &emsp;&emsp;&emsp;&emsp;&emsp;&emsp; 16

### Chapter 5: Final Result
- 5.1 Output and Interface &emsp;&emsp;&emsp;&emsp;&emsp;&emsp; 19
- 5.2 Evaluation Methods Used &emsp;&emsp;&emsp;&emsp; 22
- 5.3 Results and Performance &emsp;&emsp;&emsp;&emsp; 22

### Chapter 6: Conclusion and Future Scope
- 6.1 Conclusion &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; 23
- 6.2 Significance of the System &emsp;&emsp;&emsp;&emsp; 23
- 6.3 Limitations of the System &emsp;&emsp;&emsp;&emsp; 24
- 6.4 Future Scope &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; 24

### Chapter 7: References &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; 25

---

## LIST OF FIGURES

### Chapter 2: Data Description
- 2.7.1 Employee Dashboard Overview &emsp;&emsp;&emsp;&emsp; 09
- 2.7.2 Weekly Productivity Trend Chart &emsp;&emsp;&emsp; 10
- 2.7.3 App Usage Distribution &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; 10
- 2.7.4 Workforce Behavior Distribution &emsp;&emsp;&emsp; 11
- 2.7.5 Team Productivity Comparison &emsp;&emsp;&emsp;&emsp; 11

### Chapter 4: Project Analysis
- 4.1.1 System Architecture &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; 15
- 4.1.2 Application Flowchart &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; 15

### Chapter 5: Final Result
- 5.1.1 Login Interface &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; 19
- 5.1.2 Employee Dashboard &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; 19
- 5.1.3 Activity Logging Form &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; 20
- 5.1.4 Admin Dashboard Overview &emsp;&emsp;&emsp;&emsp;&emsp; 20
- 5.1.5 Employee Management View &emsp;&emsp;&emsp;&emsp;&emsp; 21
- 5.1.6 Team Analytics &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; 21
- 5.1.7 Reports Export Section &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; 22

---

# CHAPTER 1: INTRODUCTION

## 1.1 Background

In the modern digital workplace, understanding employee productivity and work patterns has become increasingly important for organizational success. With the rise of remote work and digital collaboration tools, organizations need effective methods to monitor work patterns while respecting employee privacy and autonomy.

Human productivity analysis involves tracking digital behavior metrics such as application usage time, task categorization, work session durations, and productivity patterns. These metrics provide valuable insights into workforce efficiency, helping organizations identify high performers, detect burnout risks, and optimize team dynamics.

This project develops a comprehensive **Human Productivity Tracker** that allows employees to manually log their digital activities while providing administrators with aggregated analytics. The system categorizes applications as productive (VS Code, Excel, Jira), neutral (Email, Calendar), or unproductive (Social Media, Entertainment), calculating productivity scores and burnout risk assessments based on usage patterns.

The platform uses modern web technologies including HTML5, CSS3, JavaScript, and Chart.js for visualization, with a REST API backend for data management. The dual-dashboard approach ensures that both individual employees and administrators have access to relevant insights tailored to their roles.

## 1.2 Problem Definition

The primary goal of this project is to create a comprehensive **Human Productivity Tracking Platform** that:

1. Enables employees to manually log their application usage and work activities
2. Calculates productivity scores based on categorized application usage
3. Assesses burnout risk levels from work pattern analysis
4. Provides administrators with workforce-wide analytics and team comparisons
5. Generates exportable reports for HR decision-making
6. Maintains user privacy through transparent, consent-based data collection

The system addresses the challenge of measuring digital workforce productivity without invasive automatic monitoring, providing a privacy-conscious alternative that relies on voluntary activity logging.

## 1.3 Objectives

- **Develop a Dual-Dashboard System**: Create separate interfaces for Employees (personal productivity tracking) and Administrators (workforce analytics) using modern web technologies.

- **Implement Activity Logging Module**: Build a comprehensive form-based system for logging application usage, task categories, time spent, and descriptions with automatic duration calculation.

- **Create Productivity Scoring Algorithm**: Develop algorithms that calculate productivity percentages based on categorized application usage (productive, neutral, unproductive).

- **Build Burnout Risk Assessment**: Implement risk assessment functionality that identifies employees at risk of burnout based on work hours and patterns.

- **Visualize Analytics Data**: Use Chart.js to create interactive visualizations including line charts for trends, doughnut charts for distributions, and bar charts for team comparisons.

- **Enable Report Generation**: Provide CSV export functionality for productivity reports, attendance records, behavior analysis, and team performance data.

- **Ensure Secure Authentication**: Implement role-based login system with differentiated access levels for Employees and Administrators.

## 1.4 Purpose

The purpose of this project is to provide organizations with a transparent, privacy-conscious tool for understanding workforce productivity patterns. By enabling voluntary activity logging rather than automatic surveillance, the system:

1. **Empowers Employees**: Gives workers visibility into their own productivity patterns and work habits
2. **Supports HR Decision-Making**: Provides data-driven insights for workforce planning and intervention strategies
3. **Identifies At-Risk Employees**: Helps detect potential burnout situations before they become critical
4. **Promotes Work-Life Balance**: Encourages healthy work patterns through self-awareness and feedback
5. **Facilitates Team Optimization**: Enables managers to understand team dynamics and productivity distributions

## 1.5 Scope

This project focuses on a web-based productivity tracking system with the following scope:

**Included Features:**
- Role-based authentication (Admin/Employee)
- Manual activity logging with application categorization
- Real-time productivity score calculation
- Burnout risk assessment (LOW, MEDIUM, HIGH)
- Behavior classification (High Performer, Average, Low Engagement, Burnout Risk)
- Weekly trend analysis and historical data viewing
- Team-level and organization-level analytics
- CSV report generation and download

**System Components:**
- Login Interface with demo credentials
- Employee Dashboard (Overview, Log Activity, History, Insights)
- Admin Dashboard (Overview, Employees, Team Analytics, Reports)
- REST API backend for data operations

## 1.6 Applicability

This Human Productivity Tracker can be used by:

- **HR Professionals**: For workforce analysis, productivity monitoring, and burnout prevention strategies
- **Team Managers**: To understand team performance patterns and identify employees needing support
- **Executive Leadership**: For strategic workforce planning and organizational productivity assessment
- **Individual Employees**: For self-monitoring, productivity improvement, and work-life balance management
- **Remote Work Organizations**: To maintain visibility into distributed workforce productivity

The insights provided support informed decision-making in areas such as:
- Performance reviews and feedback
- Workload distribution and team balancing
- Intervention for at-risk employees
- Productivity improvement initiatives

## 1.7 Achievements

The Human Productivity Tracker project has successfully achieved the following milestones:

### Technical Achievements:
- **Complete Web Application**: Built a fully functional dual-dashboard system using HTML5, CSS3, and JavaScript with responsive design supporting both desktop and mobile views.
- **Interactive Visualizations**: Integrated Chart.js library for real-time charts including line graphs, doughnut charts, and bar charts with dynamic data updates.
- **REST API Integration**: Implemented comprehensive API endpoints for authentication, activity logging, metrics retrieval, and analytics aggregation.
- **Theme Support**: Added dark/light mode toggle functionality with persistent user preferences.

### Functional Achievements:
- **Activity Logging System**: Successfully implemented form-based activity logging with 15+ application options categorized across productive, neutral, and unproductive categories.
- **Productivity Analytics**: Delivered real-time productivity score calculation with 7-day trend analysis and weekly averages.
- **Burnout Detection**: Implemented automated burnout risk classification based on work patterns and logged hours.
- **Report Generation**: Created CSV export functionality for four report types (Productivity, Attendance, Behavior, Team).

### User Experience Achievements:
- **Intuitive Interface**: Achieved clean, modern UI design with consistent styling and professional aesthetics.
- **Privacy-First Approach**: Clearly communicated that no automatic tracking occurs through prominent privacy banners.
- **Demo Mode**: Provided sample credentials for immediate system exploration without setup requirements.

## 1.8 Organisation of Report

This project report is systematically organized into seven comprehensive chapters:

**Chapter 1: Introduction** - Establishes the foundation by presenting background context, problem definition, objectives, purpose, scope, applicability, and achievements of the Human Productivity Tracker.

**Chapter 2: Data Description** - Provides comprehensive coverage of the data structure, including activity logs, productivity metrics, user information, and session data with schema definitions and visualization examples.

**Chapter 3: Models and Algorithms** - Details the productivity scoring algorithm, burnout risk assessment methodology, behavior classification system, and technology stack used.

**Chapter 4: Project Analysis** - Presents system architecture, application flowcharts, package documentation, and code structure analysis.

**Chapter 5: Final Result** - Demonstrates the completed system through interface screenshots, evaluation methods, and performance results.

**Chapter 6: Conclusion and Future Scope** - Synthesizes project outcomes, highlights system significance, acknowledges limitations, and proposes future enhancements.

**Chapter 7: References** - Provides bibliography of technical documentation and resources used.

---

# CHAPTER 2: DATA DESCRIPTION

## 2.1 Data Source and Extraction

The Human Productivity Tracker uses multiple data entities to track and analyze employee digital behavior:

1. **User Data**: Employee profiles including name, email, team assignment, and role
2. **Activity Logs**: Manual entries of application usage with timestamps and descriptions
3. **Productivity Metrics**: Calculated daily scores based on activity categorization
4. **Work Sessions**: Login/logout times and total daily work duration
5. **Team Analytics**: Aggregated team-level performance metrics

Data extraction is performed through REST API calls to the backend server, which processes and returns JSON-formatted data for the dashboard interfaces.

## 2.2 Explaining the Data

The system manages the following key data attributes:

### User Entity:
- **user_id**: Unique identifier for each employee
- **name**: Full name of the employee
- **email**: Email address (used for login)
- **team**: Department/team assignment (Engineering, Marketing, Sales, Design, HR)
- **role**: System role (EMPLOYEE or ADMIN)
- **avatar**: Initials for profile display
- **work_behavior**: Classified behavior pattern

### Activity Log Entity:
- **log_id**: Unique identifier for each activity entry
- **user_id**: Reference to the employee
- **application**: Name of application used (VS Code, Excel, YouTube, etc.)
- **app_category**: Classification (productive, neutral, unproductive)
- **task_category**: Work category (Development, Documentation, Communication, etc.)
- **start_time**: Activity start timestamp
- **end_time**: Activity end timestamp
- **duration**: Time spent in minutes
- **task_description**: Optional description of work performed

### Productivity Metrics Entity:
- **metric_id**: Unique identifier
- **user_id**: Reference to employee
- **date**: Date of measurement
- **productivity_score**: Calculated percentage (0-100)
- **productive_minutes**: Total productive application time
- **neutral_minutes**: Total neutral application time
- **unproductive_minutes**: Total unproductive application time
- **burnout_risk**: Risk level (LOW, MEDIUM, HIGH)

## 2.3 Data Management and Modeling

### 2.3.1 Data Management Approach

The data management strategy follows a structured approach:

1. **Data Collection**: Form-based input from employees with validation
2. **Data Categorization**: Automatic classification of applications by productivity category
3. **Data Aggregation**: Real-time calculation of daily and weekly metrics
4. **Data Storage**: JSON-based storage with API endpoints for CRUD operations
5. **Data Security**: Role-based access control limiting data visibility

### 2.3.2 Data Model Schema

| Field Name | Data Type | Description | Example |
|------------|-----------|-------------|---------|
| user_id | Integer | Unique employee identifier | 1, 2, 3... |
| name | String | Employee full name | "Amit Sharma" |
| email | String | Login email | "amit@company.com" |
| team | Categorical | Work team | "Engineering", "Sales" |
| role | Enum | System access role | "EMPLOYEE", "ADMIN" |
| application | String | App name | "VS Code", "Chrome" |
| app_category | Categorical | Productivity class | "productive", "neutral" |
| productivity_score | Integer | Daily score (0-100) | 75, 82, 68... |
| burnout_risk | Categorical | Risk assessment | "LOW", "MEDIUM", "HIGH" |
| work_behavior | Categorical | Behavior pattern | "High Performer", "Average" |

## 2.4 Data Pre-processing

Data preprocessing steps include:

- **Input Validation**: Ensuring required fields are completed before submission
- **Time Calculation**: Automatic duration computation from start/end times
- **Category Mapping**: Mapping application names to productivity categories
- **Score Normalization**: Converting raw minutes to percentage scores
- **Date Formatting**: Standardizing timestamps for consistent analysis

**Application Category Mapping:**

| Category | Applications |
|----------|-------------|
| Productive | VS Code, Excel, Jira, Slack (Work), Google Docs, Figma, IntelliJ, Postman, Terminal, Zoom (Meeting) |
| Neutral | Chrome, Outlook, Teams, Notion, Calendar, Notes |
| Unproductive | YouTube, Twitter, Instagram, Reddit, Netflix, Gaming |

## 2.5 Data Engineering

The data engineering pipeline includes:

- **Activity Aggregation**: Summing daily minutes by category for score calculation
- **Trend Computation**: Calculating 7-day rolling averages for trend analysis
- **Risk Scoring**: Implementing thresholds for burnout risk determination
- **Team Aggregation**: Computing team-level averages from individual metrics
- **Behavior Classification**: Categorizing employees based on productivity patterns

**Productivity Score Formula:**
```
Productivity Score = (Productive Minutes / Total Logged Minutes) × 100
```

**Burnout Risk Thresholds:**
- HIGH: Logged hours > 10/day OR productivity < 40%
- MEDIUM: Logged hours > 8/day AND productivity 40-60%
- LOW: Normal hours AND productivity > 60%

## 2.6 Data Analysis

Comprehensive data analysis reveals:

- **Daily Patterns**: Tracking productivity variations across weekdays
- **Application Distribution**: Understanding time allocation across apps
- **Team Comparisons**: Comparing productivity across organizational teams
- **Behavior Distributions**: Analyzing workforce segmentation by performance
- **Trend Analysis**: Identifying improving or declining productivity patterns
- **Risk Assessment**: Monitoring burnout indicators across the workforce

## 2.7 Data Visualization

The dashboard provides multiple visualization types:

### Fig. 2.7.1 Employee Dashboard Overview
Main employee interface showing key metrics cards (Today's Hours, Productivity Score, Tasks Logged, Burnout Risk) with quick navigation to activity logging and history sections.

### Fig. 2.7.2 Weekly Productivity Trend Chart
Line chart displaying 7-day productivity score trend with smooth curve interpolation, helping employees identify patterns in their work habits.

### Fig. 2.7.3 App Usage Distribution
Doughnut chart showing the breakdown of time spent across productive (green), neutral (yellow), and unproductive (red) applications.

### Fig. 2.7.4 Workforce Behavior Distribution
Pie chart on admin dashboard showing the distribution of employees across behavior categories: High Performer, Average, Low Engagement, and Burnout Risk.

### Fig. 2.7.5 Team Productivity Comparison
Bar chart comparing average productivity scores across different teams (Engineering, Marketing, Sales, Design, HR) with color-coded performance indicators.

---

# CHAPTER 3: MODELS AND ALGORITHMS

## 3.1 Productivity Score Calculation

The productivity score algorithm categorizes logged activities and calculates a weighted percentage:

```javascript
// Productivity Calculation Logic
function calculateProductivityScore(logs) {
    const productive = logs.filter(l => l.app_category === 'productive')
        .reduce((sum, l) => sum + l.duration, 0);
    const neutral = logs.filter(l => l.app_category === 'neutral')
        .reduce((sum, l) => sum + l.duration, 0);
    const unproductive = logs.filter(l => l.app_category === 'unproductive')
        .reduce((sum, l) => sum + l.duration, 0);
    
    const total = productive + neutral + unproductive;
    if (total === 0) return 0;
    
    // Weighted formula: Productive=100%, Neutral=50%, Unproductive=0%
    const score = ((productive * 1.0) + (neutral * 0.5)) / total * 100;
    return Math.round(score);
}
```

**Key Features:**
- Productive applications contribute fully to the score
- Neutral applications contribute 50%
- Unproductive applications contribute 0%
- Score range: 0-100%

## 3.2 Burnout Risk Assessment

The burnout risk algorithm evaluates multiple factors:

```javascript
function assessBurnoutRisk(metrics, sessions) {
    const avgHoursPerDay = calculateAverageHours(sessions);
    const avgProductivity = calculateAverageProductivity(metrics);
    const consecutiveHighHours = countConsecutiveHighHourDays(sessions);
    
    if (avgHoursPerDay > 10 || consecutiveHighHours > 5) {
        return 'HIGH';
    } else if (avgHoursPerDay > 8 && avgProductivity < 60) {
        return 'MEDIUM';
    }
    return 'LOW';
}
```

**Risk Indicators:**
| Risk Level | Criteria |
|------------|----------|
| HIGH | >10 hours/day average OR >5 consecutive high-hour days |
| MEDIUM | >8 hours/day AND productivity <60% |
| LOW | Normal hours with healthy productivity |

## 3.3 Behavior Classification

Employee behavior is classified based on historical patterns:

```javascript
function classifyBehavior(avgProductivity, burnoutRisk, consistency) {
    if (avgProductivity >= 80 && burnoutRisk === 'LOW') {
        return 'High Performer';
    } else if (burnoutRisk === 'HIGH') {
        return 'Burnout Risk';
    } else if (avgProductivity < 50) {
        return 'Low Engagement';
    }
    return 'Average';
}
```

**Classification Categories:**
- **High Performer**: Consistently high productivity (≥80%) with healthy work patterns
- **Average**: Moderate productivity (50-79%) with stable patterns
- **Low Engagement**: Below-average productivity (<50%) requiring attention
- **Burnout Risk**: High work hours with declining or unstable performance

## 3.4 Technologies Used

| Technology | Version | Purpose |
|------------|---------|---------|
| HTML5 | 5.0 | Page structure and semantic markup |
| CSS3 | 3.0 | Styling, animations, responsive design |
| JavaScript | ES6+ | Client-side logic and interactivity |
| Chart.js | 4.0+ | Interactive data visualizations |
| REST API | - | Backend data communication |
| Local Storage | - | Client-side session management |
| Fetch API | - | Asynchronous HTTP requests |

**Frontend Architecture:**
- Vanilla JavaScript (no framework dependencies)
- CSS Grid and Flexbox for responsive layouts
- CSS Custom Properties for theming (dark/light mode)
- Modular file organization (separate CSS/JS files)

## 3.5 Evaluation Methods

The system employs multiple evaluation approaches:

- **Accuracy Validation**: Cross-checking calculated scores against manual computations
- **User Acceptance Testing**: Feedback collection on interface usability
- **Performance Testing**: Measuring page load times and chart rendering speed
- **Responsiveness Testing**: Verifying functionality across device sizes
- **Security Testing**: Validating authentication and role-based access

## 3.6 Deployment

Deployment architecture:

- **Frontend Hosting**: Static file serving for HTML/CSS/JS
- **API Integration**: RESTful endpoints for data operations
- **Authentication**: Session-based login with localStorage persistence
- **Theme Persistence**: User preference storage for dark/light mode
- **Responsive Design**: Mobile-first approach with desktop enhancements

---

# CHAPTER 4: PROJECT ANALYSIS

## 4.1 System Design

### Fig. 4.1.1 System Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                        USER INTERFACE                           │
├─────────────────────────┬───────────────────────────────────────┤
│   Employee Dashboard    │         Admin Dashboard               │
│  ┌─────────────────┐    │    ┌─────────────────┐                │
│  │ Overview        │    │    │ Workforce       │                │
│  │ Log Activity    │    │    │ Overview        │                │
│  │ History         │    │    │ Employees       │                │
│  │ Insights        │    │    │ Team Analytics  │                │
│  └─────────────────┘    │    │ Reports         │                │
│                         │    └─────────────────┘                │
├─────────────────────────┴───────────────────────────────────────┤
│                     PRESENTATION LAYER                          │
│              (HTML5, CSS3, JavaScript, Chart.js)                │
├─────────────────────────────────────────────────────────────────┤
│                        API LAYER                                │
│           (REST Endpoints, JSON Data Exchange)                  │
├─────────────────────────────────────────────────────────────────┤
│                      DATA LAYER                                 │
│        (Users, Activity Logs, Metrics, Sessions)                │
└─────────────────────────────────────────────────────────────────┘
```

### Fig. 4.1.2 Application Flowchart

```
                    ┌───────────────┐
                    │    START      │
                    └───────┬───────┘
                            │
                    ┌───────▼───────┐
                    │  Login Page   │
                    └───────┬───────┘
                            │
                    ┌───────▼───────┐
                    │ Authenticate  │
                    └───────┬───────┘
                            │
              ┌─────────────┼─────────────┐
              │                           │
      ┌───────▼───────┐           ┌───────▼───────┐
      │ Role: ADMIN   │           │Role: EMPLOYEE │
      └───────┬───────┘           └───────┬───────┘
              │                           │
      ┌───────▼───────┐           ┌───────▼───────┐
      │Admin Dashboard│           │ Employee      │
      │  - Overview   │           │ Dashboard     │
      │  - Employees  │           │  - Overview   │
      │  - Analytics  │           │  - Log Work   │
      │  - Reports    │           │  - History    │
      └───────┬───────┘           │  - Insights   │
              │                   └───────┬───────┘
              │                           │
              └─────────────┬─────────────┘
                            │
                    ┌───────▼───────┐
                    │    Logout     │
                    └───────┬───────┘
                            │
                    ┌───────▼───────┐
                    │     END       │
                    └───────────────┘
```

## 4.2 Packages Used and Implementation

| File | Type | Purpose |
|------|------|---------|
| index.html | HTML | Login page structure |
| employee.html | HTML | Employee dashboard layout |
| admin.html | HTML | Admin dashboard layout |
| styles.css | CSS | Global styles and utilities |
| login.css | CSS | Login page specific styles |
| dashboard.css | CSS | Dashboard common styles |
| admin.css | CSS | Admin-specific styling |
| login.js | JavaScript | Authentication logic |
| employee.js | JavaScript | Employee dashboard logic |
| admin.js | JavaScript | Admin dashboard logic |
| theme.js | JavaScript | Dark/light mode toggle |
| Chart.js (CDN) | Library | Data visualization charts |

## 4.3 Code Flow and Logic

### Main Application Structure:

```
1. Page Load → Check Authentication
2. If Not Authenticated → Redirect to Login
3. If Authenticated → Load Dashboard Based on Role
4. Initialize Navigation Event Listeners
5. Load Data via API Calls
6. Render Charts and Tables
7. Handle User Interactions
```

### Key Modules:

**Authentication Module:**
- Form validation and submission
- API call to /api/login endpoint
- LocalStorage session management
- Role-based redirect logic

**Activity Logging Module:**
- Form with application dropdown (categorized)
- Auto-duration calculation from time inputs
- API submission to /api/app-usage
- UI update after successful log

**Analytics Module:**
- API calls to /api/productivity, /api/analytics
- Data aggregation and processing
- Chart.js visualization rendering
- Dynamic table population

**Report Generation Module:**
- Data compilation from loaded metrics
- CSV string generation
- Download trigger via Blob/URL

### API Endpoints:

| Endpoint | Method | Description |
|----------|--------|-------------|
| /api/login | POST | User authentication |
| /api/employees | GET | List all employees |
| /api/productivity | GET | Get productivity metrics |
| /api/app-usage | GET/POST | Activity log operations |
| /api/sessions | GET/POST | Work session management |
| /api/analytics/overview | GET | Workforce summary |
| /api/analytics/trends | GET | Time-series data |
| /api/analytics/team | GET | Team-level analytics |

---

# CHAPTER 5: FINAL RESULT

## 5.1 Output and Interface

### Fig. 5.1.1 Login Interface
Secure login page featuring:
- Email and password input fields
- Demo credentials display for testing
- Dark/light theme toggle
- Privacy banner stating no automatic tracking
- Role badge indicators (Employee/Admin)

### Fig. 5.1.2 Employee Dashboard
Main employee view displaying:
- Four metric cards (Today's Hours, Productivity Score, Tasks Logged, Burnout Risk)
- Session start/stop button with status indicator
- Weekly productivity trend line chart
- App usage distribution doughnut chart
- Today's activity log table

### Fig. 5.1.3 Activity Logging Form
Comprehensive form including:
- Application dropdown (categorized by productivity)
- Task category selection
- Start/end time pickers with auto-duration
- Task description textarea
- Submit and clear buttons

### Fig. 5.1.4 Admin Dashboard Overview
Workforce summary featuring:
- Total employees count
- Average workforce productivity
- Active teams count
- Employees with burnout risk
- Workforce productivity trend chart
- Behavior distribution chart
- Employee performance overview table

### Fig. 5.1.5 Employee Management View
Full employee listing with:
- Search and filter capabilities
- Team filter dropdown
- Behavior filter dropdown
- Employee cards with avatars
- Quick metrics (7-day average, behavior, status)
- Click-to-view detailed modal

### Fig. 5.1.6 Team Analytics
Team comparison section showing:
- Team cards with member count and score
- Progress bars with color-coded performance
- Behavior breakdown per team
- Team comparison bar chart

### Fig. 5.1.7 Reports Export Section
Report generation panel with:
- Productivity Report (CSV)
- Attendance Report (CSV)
- Behavior Analysis (CSV)
- Team Performance (CSV)
- Record count and date range display

## 5.2 Evaluation Methods Used

- **Functional Testing**: Verified all features work as designed
- **User Interface Testing**: Confirmed responsive behavior across devices
- **Performance Testing**: Measured chart rendering and API response times
- **Security Testing**: Validated role-based access restrictions
- **Usability Testing**: Gathered feedback on navigation and workflow

## 5.3 Results and Performance

| Metric | Result |
|--------|--------|
| Page Load Time | <1.5 seconds |
| Chart Render Time | <500ms |
| API Response Time | <200ms average |
| Mobile Responsiveness | Fully responsive |
| Browser Compatibility | Chrome, Firefox, Safari, Edge |
| Authentication Security | Role-based access enforced |
| Data Export | CSV generation successful |

---

# CHAPTER 6: CONCLUSION AND FUTURE SCOPE

## 6.1 Conclusion

The Human Productivity Tracker successfully delivers a comprehensive digital behavior monitoring platform that balances organizational needs for productivity insights with individual privacy concerns. By implementing a manual activity logging approach rather than automatic surveillance, the system provides valuable analytics while maintaining ethical data collection practices.

The dual-dashboard architecture effectively serves both employees (for self-improvement and awareness) and administrators (for workforce management and planning). The integration of Chart.js visualizations provides intuitive understanding of productivity patterns, while the burnout risk assessment adds preventive HR capabilities.

The project demonstrates the viability of privacy-conscious productivity tracking tools in modern workplaces, offering a prototype that can be expanded for real-world deployment.

## 6.2 Significance of the System

- **Privacy-First Design**: Establishes trust through transparent, voluntary data collection
- **Employee Empowerment**: Provides individuals with insights into their own work patterns
- **Proactive HR Management**: Enables early intervention for burnout prevention
- **Data-Driven Decisions**: Supports evidence-based workforce planning
- **Team Optimization**: Facilitates understanding of team dynamics and performance
- **Flexible Deployment**: Web-based architecture allows access from any device

## 6.3 Limitations of the System

- **Manual Entry Dependency**: Relies on user discipline for accurate logging
- **Prototype Data**: Uses synthetic/demo data for demonstration
- **No Real-Time Tracking**: Does not capture automatic application usage
- **Single-Organization Scope**: Designed for single organization use
- **Limited ML Integration**: Basic algorithms without advanced machine learning
- **No Mobile App**: Web-only interface without native mobile applications

## 6.4 Future Scope

- **Optional Automatic Tracking**: Add consent-based background application monitoring
- **Advanced ML Models**: Implement predictive analytics for turnover and performance
- **Integration APIs**: Connect with HR systems (Workday, BambooHR, etc.)
- **Mobile Applications**: Develop iOS and Android native apps
- **Real-Time Notifications**: Push alerts for unusual patterns or milestones
- **Gamification Features**: Add achievements and goals for motivation
- **Multi-Organization Support**: Enable SaaS-style multi-tenant architecture
- **AI-Powered Insights**: Natural language summaries of productivity patterns
- **Calendar Integration**: Sync with Google Calendar, Outlook for context
- **Wellness Recommendations**: Personalized suggestions based on work patterns

---

# CHAPTER 7: REFERENCES

1. **Chart.js Documentation**
   - https://www.chartjs.org/docs/

2. **MDN Web Docs - JavaScript**
   - https://developer.mozilla.org/en-US/docs/Web/JavaScript

3. **MDN Web Docs - CSS**
   - https://developer.mozilla.org/en-US/docs/Web/CSS

4. **REST API Design Best Practices**
   - https://restfulapi.net/

5. **Web Accessibility Guidelines (WCAG)**
   - https://www.w3.org/WAI/standards-guidelines/wcag/

6. **Research Papers:**
   - "Digital Productivity Monitoring: Balancing Organizational Needs and Employee Privacy"
   - Journal of Workplace Technology Studies

7. **CSS Grid and Flexbox Guide**
   - https://css-tricks.com/snippets/css/complete-guide-grid/

8. **JavaScript ES6+ Features**
   - https://es6.io/

---

*End of Document*
