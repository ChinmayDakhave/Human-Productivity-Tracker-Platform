"use client"

import { useEffect } from "react"

export default function Home() {
  useEffect(() => {
    // Redirect to the static login page
    window.location.href = "/index.html"
  }, [])

  return (
    <div className="flex min-h-screen items-center justify-center bg-background">
      <div className="text-center">
        <div className="mb-4 flex justify-center">
          <svg width="48" height="48" viewBox="0 0 40 40" fill="none">
            <rect width="40" height="40" rx="8" fill="#2563eb" />
            <path d="M12 20H28M20 12V28" stroke="white" strokeWidth="3" strokeLinecap="round" />
          </svg>
        </div>
        <h1 className="text-2xl font-bold text-foreground">Human Productivity Tracker</h1>
        <p className="mt-2 text-muted-foreground">Redirecting to login...</p>
      </div>
    </div>
  )
}
